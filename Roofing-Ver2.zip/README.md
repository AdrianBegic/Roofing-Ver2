https://adrianbegic.github.io/Roofing-Ver2/
